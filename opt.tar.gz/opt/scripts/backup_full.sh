#!/bin/bash


mostrar_ayuda() {
    echo "Uso: $0 ORIGEN DESTINO"
    echo
    echo "Descripción:"
    echo "  Realiza un backup comprimido (.tar.gz) del directorio origen."
    echo
    echo "Parámetros:"
    echo "  ORIGEN   Directorio a respaldar."
    echo "  DESTINO  Directorio donde se guardará el backup."
    echo
    echo "Opciones:"
    echo "  -help    Muestra esta ayuda."
    echo
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
}

# Opción de ayuda
if [ "$1" = "-help" ]; then
    mostrar_ayuda
    exit 0
fi

# Validar cantidad de parámetros
if [ $# -ne 2 ]; then
    echo "Error: cantidad incorrecta de parámetros."
    mostrar_ayuda
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Verificar existencia de directorios
if [ ! -d "$ORIGEN" ]; then
    echo "Error: el directorio origen no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: el directorio destino no existe."
    exit 1
fi

# Verificar disponibilidad de sistemas de archivos
df "$ORIGEN" > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "Error: sistema de archivos origen no disponible."
    exit 1
fi

df "$DESTINO" > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "Error: sistema de archivos destino no disponible."
    exit 1
fi

# Obtener fecha ANSI YYYYMMDD
FECHA=$(date +%Y%m%d)

# Obtener nombre del directorio sin la ruta
NOMBRE_DIR=$(basename "$ORIGEN")

# Generar nombre del archivo
ARCHIVO="${NOMBRE_DIR}_bkp_${FECHA}.tar.gz"

echo "Iniciando backup..."

tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

if [ $? -eq 0 ]; then
    echo "Backup realizado correctamente."
    echo "Archivo generado:"
    echo "$DESTINO/$ARCHIVO"
else
    echo "Error al generar el backup."
    exit 1
fi

exit 0
