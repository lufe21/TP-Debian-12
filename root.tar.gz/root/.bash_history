history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
ls
cd ..
ls 
nano hola
su -
clear
hostnamectl set-hostname TPServer
nano /etc/hostname
ls
cd
cd --
cd. dc 
cd ..
cd ..
clear
apt install nano 
touch hola
ls
nano hola
su -
nano hola
apt install nano
clear
rm hola
ls
 cd .. 
rm hola
ls
cd etc
ls
cd hostname
cat hostname
clear
cd ..
clear
hostname
cd /etc/hostname
clear
cd /etc
cat hostname
c
cd ..
shutdown now
clear 
apt install nano
clear 

vi /etc/apt/sources.list
clear
vi /etc/apt/sources.list
cat /etc/apt/sources.list
clear }
clear
apt update
vi /etc/apt/sources.list
apt update
apt upgrade
cat /etc/so-release
cat /etc/so-release
cat /etc/os-release
clear
cat /etc/os-release
apt update
apt list --upgradable
apt update
apt upgrade
clear
apt update
vi /etc/apt/sources.list
apt update
apt list --upgradable
clear
apt update
apt list --upgradable
apt upgrade
apt autoremove
apt update
apt upgrade
clear
apt full-upgrade
apt update
cleatr
clear
apt install openssh-server
clear
systemctl status ssh
clear
ssh-keygen
cat /root/.ssh/id_rsa.pub
ls
cd..
cd ..
ls
cd home
ls
cd ..
/root
cd /root
ls
cd /root/ssh 
cd /root/.ssh
ls
clear
ls
clear
cd ..
cd ..
cd /etc/ssh
ls
nano sshd_config
vi sshd_config
cd ..
cd ..
ls -l /root/.ssh
ls /root/.ssh
clear
shutdown now
cd /root/.ssh 
ls
nano authorized_keys
rmdir authorized_keys
ls
touch authorized_keys
ls
nano authorized_keys
nano authorized_keys
ls
mv /root/.ssh authorized_keys
rm authorized_keys
ls
cd /root/.ssh
ls
cat
nano authorized_keys
cat authorized_keys
clear
exit
exit
clear
cls
exit
exit
clear
ls
cd 
nano /etc/ssh/sshd_config
cat /etc/ssh/sshd_config
nano /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
exit
ip a
exit
exit
clear
apt install apache
apt update
apt full-upgrade
clear
apt install apache2 php libapache2-mod-php -y
systemctl status apache2
clear
o´a
ip a}
ip a
php -v
cd
cd /root
"C:\Users\luche\Desktop\TP LINUX\index.php"
ls
C:\Users\luche\Desktop\TP LINUX\index.php
scp -P 2222 "C:\Users\luche\Desktop\index.php" root@127.0.0.1:/root/
scp -P 2222 "C:\Users\luche\Desktop\index.php" root@127.0.0.1:/root/
exit
exit
shutdown now
apt update
apt full-upgrade
ls
apt install mariadb-server mariadb-client -y
systemctl status mariadb-server
systemctl status mariadb
c
exit
ls
cd /var/www
ls
cd html
ls
cd ..
cd
rm index.php
ls
cd /var/www/html
ls
cd
vi db.sql
cd /etc
ls
cd mysql
ls
vi mariadb.cnf
cd ..
cd netconfig
cat netconfig
ls 
mysql
mysql
ls
cd 
ls
cd root 
mysql -u root
mysql -u root -p < /root/db.sql
ls
mysql -u root
mysql 
clear
ls
mysql
ls 
cd ..
cd ..
cd /etc
ls
cd mysql
ls
cd ..
cd ..
ls -a
ls root
cd root
ls
ls -a
cd .mysql_history
cat mysql_history
cat .mysql_history
cd .. 
exit
ols
ls
cls
clear
cd /etc/network
ls
vi interfaces
ls
cat interfaces-d
cat interfaces.d
cd ..
clear
exit
sssssss
shutdown now
ls
cd etc
cd /etc
ñs
ls
visudo
clear
ls
vi shadow
clea
clear
vi passwd
vi gropu
vi group
clear
ls
cd kernel
ls
vi install .d
ls
clear
ls -a
cd
ls
cd ..
ls
ls sbin
cd sbin
ls
vi cledar
clear
cs
cd
cd /etc/apt
ls
cd ..
ls
cd vim
ls
vi vimrc
clear
shutdown now
vim
clear
vi /etc/network/interface
clear
cd /etc
cd /network 
ls
cd network
ls
vi interfaces
cat interfaces
reboot
ip a 
ip link set enp0s3 up
dhclient enp0s3
ip a
cd /etc/network
cat interface
cat interfaces
systemctl restart networking
cat interfaces
vi interfaces
cat interfaces
dhclient enp0s3
dhclient enp0s3
clear
ip a
reboot
ls
systemctl restart networking
vi /etc/network/interfaces
clear
ip a
ip enp0s3 up
ip link set enp0s3 up
ip a
dhclient enp0s3
ip a
clear
vi /etc/network/interfaces
clear
nano /etc/network/interfaces
clear
ip link set enp0s3 down
ifup enp0s3
ip addr show enp0s3
ip a
reboot 
clear
systemctl status networking
ip link show
ip route
nano /etc/network/interfaces
systemctl restart networking
systemctl status networking.service
journalctl -xeu networking.service
clear
ip addr flush dev enp0s3
ping -c 4 192.168.0.1
ip a
shutdown 
shutdown  now
ls 
cd /html
cd /var
cd html
ls
cd www
cd html
ls 
rm index.html
ls
nano index.php
ls -l 
systemctl status apache2
ls -l 
php -v
iptables -L | grep 80
curl http://localhost
curl http://localhost
apache2ctl -t
php -v
curl http://localhost/index.php
tail -n 30 /var/log/apache2/error.log
clear
apt install php-mysql -y
systemctl restart apache2 
lsbdk
lsblk
ls 
reboot
cd /etc/fstab
cd /etc
cat fstab
clear
fdisk /dev/sdd
fdisk /dev/sdc 
clear
lsbdk
lsblk
fsdisk /dev/sdc 
fdisk /dev/sdc 
lsbdk
lsblk
clear
lsblk
fdisk /dev/sdc
lsblk
cd
cd /www_dir
cat /etc/apache2/sites-available/000-default.conf
lsdlk
lsblk
mkfs.ext4 /dev/sdc1
mkdir /www_dir
mount /dev/sdc1 /www_dir
df -h
celar
clear
mkdir /backup_dir
rmdir /backup_dir
ls
cd
ls
cd /
ls
clear
mkfs.ext4 /dev/sdc2
mkdir /backup_dir
mount /dev/sdc2 /backup_dir
df -h
cp /var/www/html/index.php /www_dir/
ls /www_dir
chown -R www-data:www-data /www_dir
chmod -R 755 /www_dir
clear
nano /etc/apache2/sites-available/000-default.conf
nano /etc/apache2/sites-available/000-default.conf
clear
nano /etc/apache2/apache2.conf
clear
systemctl restart apache2
curl http://localhost
clear
blkid /dev/sdc1
blkid /dev/sdc2
nano /etc/fstab
nano /etc/fstab
nano /etc/fstab
clear
mount -a
df -h
blkid /dev/sdc1
blkid /dev/sdc2
nano /etc/fstab
lsblk
curl http://localhost
clear
shutdown now
